/**
 * auto_throttle.h
 * Closed-loop auto-throttle controller for ESP32 gyro stabilizer.
 *
 * Translated from the Simulink "ESP32 Micro-controller" subsystem.
 *
 * ── What changed from the original applyAutoThrottle() ───────────────────────
 *   Original: simple linear map  tiltMag → throttle
 *   This:     PID feedback  +  Majorana-criterion feedforward
 *
 * ── Inputs ───────────────────────────────────────────────────────────────────
 *   tiltMag   — max(|errorX|, |errorY|)  in degrees
 *               (biggest single-axis deviation, magnitude only)
 *   throttleNow — current throttle value (115–180, servo write units)
 *               treated as the "V_out" supply signal in the Simulink model
 *
 * ── Output ───────────────────────────────────────────────────────────────────
 *   int  targetThrottle — clamped to [THROTTLE_MIN, THROTTLE_MAX]
 *
 * ── Architecture ─────────────────────────────────────────────────────────────
 *
 *  tiltMag (deg)
 *      │
 *      ▼
 *  [PID feedback]──────────────────────────────────────────────────┐
 *      setpoint = 0, error = 0 – tiltMag                          │
 *      runs at Ts = 0.01 s                                        │
 *                                                                  ▼
 *  [Majorana feedforward]                                   [sum → saturate]
 *      tilt_rad = tiltMag * π/180                                  │
 *      ωs_min = √( (4·It·m·g·h / Is²) · sin(tilt_rad) )          │
 *      V_ff   = Ke · ωs_min              (voltage baseline)        │
 *      θ_ff   = voltageToThrottle(V_ff)                           │
 *                                         ───────────────────────► │
 *                                                                   ▼
 *  throttleNow (mapped to V_out)                            targetThrottle
 *      → |V_out · 0.8| → saturate → add to above ─────────────────┘
 *
 * ── Physical constants (tune to your hardware) ───────────────────────────────
 *   See AutoThrottleConfig struct below.
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *   #include "auto_throttle.h"
 *
 *   AutoThrottleController atc;          // one instance, global
 *   atc.reset();                         // call once in setup()
 *
 *   // In loop(), replace applyAutoThrottle():
 *   if (autoMode && motorRunning && refSet) {
 *       float tiltMag = max(fabsf(errorX), fabsf(errorY));
 *       int target = atc.update(tiltMag, throttle);
 *       setThrottleTarget(target);
 *   }
 */

#pragma once
#include "config.h"

// ─────────────────────────────────────────────────────────────────────────────
// AutoThrottleConfig — physical & tuning parameters
// ─────────────────────────────────────────────────────────────────────────────
struct AutoThrottleConfig
{
    // ── PID gains (tune these first) ─────────────────────────────────────────
    float Kp = 1.2f;   // proportional gain
    float Ki = 0.05f;  // integral gain
    float Kd = 0.08f;  // derivative gain

    // ── PID limits ────────────────────────────────────────────────────────────
    float integralLimit = 20.0f; // anti-windup clamp on integral term (throttle units)
    float pidOutputLimit = 30.0f; // max PID contribution to throttle

    // ── Sampling period (seconds) ─────────────────────────────────────────────
    float Ts = 0.01f; // 10 ms — matches Simulink Ts

    // ── Majorana criterion — physical parameters ──────────────────────────────
    // Tune to your gyroscope disc / rotor geometry.
    float It  = 2.5e-5f;  // transverse moment of inertia  [kg·m²]
    float Is  = 5.0e-5f;  // spin    moment of inertia     [kg·m²]
    float m   = 0.050f;   // rotor mass                    [kg]
    float h   = 0.015f;   // height of CoM above pivot     [m]
    float g   = 9.81f;    // gravitational acceleration     [m/s²]
    float Ke  = 0.003f;   // back-EMF constant             [V·s/rad]  (= 0.003 from Simulink)

    // ── Voltage ↔ throttle mapping ────────────────────────────────────────────
    // The supply path scales V_out by 0.8 (Simulink gain block).
    float supplyScale    = 0.8f;
    float batteryVoltage = 11.1f; // 3S LiPo nominal [V]

    // ── Tilt dead-band (degrees) — suppress noise at rest ────────────────────
    float tiltDeadDeg = 0.4f;
};

// ─────────────────────────────────────────────────────────────────────────────
// AutoThrottleController
// ─────────────────────────────────────────────────────────────────────────────
class AutoThrottleController
{
public:
    AutoThrottleConfig cfg;

    AutoThrottleController() { reset(); }

    /**
     * reset() — call once in setup(), or whenever motor stops.
     * Clears PID state and voltage history.
     */
    void reset()
    {
        _integral     = 0.0f;
        _prevError    = 0.0f;
        _vNowPrev     = 0.0f;
        _firstCall    = true;
    }

    /**
     * update() — call every control tick (every ~Ts seconds) from loop().
     *
     * @param tiltMag      max(|errorX|, |errorY|) in degrees
     * @param throttleNow  current throttle value (servo units, 115–180)
     * @return             new target throttle (clamped to [THROTTLE_MIN, THROTTLE_MAX])
     */
    int update(float tiltMag, int throttleNow)
    {
        // ── Dead-band ─────────────────────────────────────────────────────────
        if (tiltMag < cfg.tiltDeadDeg)
            tiltMag = 0.0f;

        // ── 1. PID feedback ───────────────────────────────────────────────────
        //   setpoint = 0  (we want zero tilt deviation)
        //   error = setpoint – tiltMag  → negative when tilted
        float error = 0.0f - tiltMag;

        float dt = cfg.Ts;
        if (_firstCall)
        {
            _prevError = error;
            _firstCall = false;
        }

        _integral += error * dt;
        _integral = constrain(_integral, -cfg.integralLimit, cfg.integralLimit);

        float derivative = (error - _prevError) / dt;
        _prevError = error;

        float pidOut = cfg.Kp * error + cfg.Ki * _integral + cfg.Kd * derivative;
        pidOut = constrain(pidOut, -cfg.pidOutputLimit, cfg.pidOutputLimit);

        // ── 2. Majorana feedforward ───────────────────────────────────────────
        //   ωs_min = √( (4·It·m·g·h / Is²) · sin(θ) )
        //   V_ff   = Ke · ωs_min
        float tiltRad  = tiltMag * (float)DEG_TO_RAD;
        float sinTilt  = sinf(tiltRad);
        if (sinTilt < 0.0f) sinTilt = 0.0f; // physics only valid for positive tilt

        float majoranaGain = (4.0f * cfg.It * cfg.m * cfg.g * cfg.h)
                             / (cfg.Is * cfg.Is);
        float omegaMinSq   = majoranaGain * sinTilt;
        float omegaMin     = (omegaMinSq > 0.0f) ? sqrtf(omegaMinSq) : 0.0f;
        float vFeedforward = cfg.Ke * omegaMin; // [V] minimum voltage to stay stable

        // ── 3. Supply voltage path (bottom Simulink section) ─────────────────
        //   V_supply = |throttleToVoltage(throttleNow) · 0.8|  (delayed by 1 step)
        //   We use the previous cycle's value as the 1/z delay.
        float vOut    = throttleToVoltage(throttleNow);
        float vSupply = fabsf(vOut * cfg.supplyScale);
        // Saturate to battery voltage
        vSupply = constrain(vSupply, 0.0f, cfg.batteryVoltage);

        // V_now = feedforward + supply contribution
        float vNow = vFeedforward + vSupply;
        vNow = constrain(vNow, 0.0f, cfg.batteryVoltage);
        _vNowPrev = vNow;

        // ── 4. Convert V_now → throttle baseline, then add PID ───────────────
        float throttleFF  = voltageToThrottle(vNow);
        float throttleOut = throttleFF + pidOut;

        return (int)constrain(throttleOut,
                              (float)THROTTLE_MIN,
                              (float)THROTTLE_MAX);
    }

    // ── Conversion helpers (public so main sketch can use them) ──────────────

    /**
     * Throttle servo value → equivalent voltage.
     * Linear map:  THROTTLE_ARM=0V,  THROTTLE_MAX=batteryVoltage
     */
    float throttleToVoltage(int thr) const
    {
        float t = (float)(thr - THROTTLE_ARM) /
                  (float)(THROTTLE_MAX - THROTTLE_ARM);
        t = constrain(t, 0.0f, 1.0f);
        return t * cfg.batteryVoltage;
    }

    /**
     * Voltage → throttle servo value.
     */
    float voltageToThrottle(float v) const
    {
        float t = v / cfg.batteryVoltage;
        t = constrain(t, 0.0f, 1.0f);
        return (float)THROTTLE_ARM + t * (float)(THROTTLE_MAX - THROTTLE_ARM);
    }

private:
    float    _integral   = 0.0f;
    float    _prevError  = 0.0f;
    float    _vNowPrev   = 0.0f;
    bool     _firstCall  = true;
};
